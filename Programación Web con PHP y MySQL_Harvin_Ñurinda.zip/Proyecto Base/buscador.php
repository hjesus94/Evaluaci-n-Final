<?php
// Establece el tipo de contenido como JSON
header('Content-Type: application/json');

// Lee el archivo JSON
$json = file_get_contents('data-1.json');

// Devuelve los datos JSON
echo $json;
?>
